"""ISEYAA — Request ID Middleware"""
import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request, Response

class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response
