"""
ISEYAA — IGR Analytics Router
===============================
Endpoints for Internally Generated Revenue analytics.
All endpoints require government_officer role minimum (enforced at API Gateway).

PRD Reference: §4.11 — Real-time IGR tracking by module
"""

from datetime import date
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse

from app.core.auth import require_role
from app.core.cache import cache_response
from app.services.igr_service import IGRService
from app.schemas.igr import (
    IGRSummaryResponse, IGRByModuleResponse, IGRByLGAResponse,
    IGRProjectionResponse, IGRExportRequest,
)

router = APIRouter()


@router.get("/summary", response_model=IGRSummaryResponse)
@cache_response(ttl=300)  # 5-minute cache — dashboard refresh rate
async def get_igr_summary(
    period: str = Query("monthly", enum=["daily", "weekly", "monthly", "quarterly", "yearly"]),
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    lga: Optional[str] = Query(None, description="Filter by specific Ogun State LGA"),
    user=Depends(require_role(["government_officer", "ministry_admin", "super_admin"])),
):
    """
    Get high-level IGR summary across all platform modules.
    Returns: total IGR, change vs prior period, top performers.
    """
    service = IGRService()
    return await service.get_summary(period=period, start_date=start_date, end_date=end_date, lga=lga)


@router.get("/by-module", response_model=IGRByModuleResponse)
@cache_response(ttl=300)
async def get_igr_by_module(
    period: str = Query("monthly"),
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    user=Depends(require_role(["government_officer", "ministry_admin", "super_admin"])),
):
    """
    IGR breakdown by platform module:
    events | marketplace | transport | utilities | hmo | sports
    """
    service = IGRService()
    return await service.get_by_module(period=period, start_date=start_date, end_date=end_date)


@router.get("/by-lga", response_model=IGRByLGAResponse)
@cache_response(ttl=300)
async def get_igr_by_lga(
    period: str = Query("monthly"),
    top_n: int = Query(10, ge=1, le=20, description="Number of top LGAs to return"),
    user=Depends(require_role(["government_officer", "ministry_admin", "super_admin"])),
):
    """
    IGR ranking by Local Government Area.
    All 20 Ogun State LGAs with revenue, vendor count, and transaction volume.
    """
    service = IGRService()
    return await service.get_by_lga(period=period, top_n=top_n)


@router.get("/projections", response_model=IGRProjectionResponse)
async def get_igr_projections(
    horizon_days: int = Query(30, ge=7, le=365),
    scenario: str = Query("base", enum=["pessimistic", "base", "optimistic"]),
    user=Depends(require_role(["ministry_admin", "super_admin"])),
):
    """
    AI-powered IGR projections using historical platform data.
    Returns confidence intervals and key assumption drivers.
    Requires ministry_admin or super_admin role.
    """
    service = IGRService()
    return await service.get_projections(horizon_days=horizon_days, scenario=scenario)


@router.get("/realtime")
async def get_igr_realtime(
    user=Depends(require_role(["government_officer", "ministry_admin", "super_admin"])),
):
    """
    Real-time IGR metrics (last 24h, live data from Redis).
    Powers the live counter on the Governor's dashboard.
    """
    service = IGRService()
    return await service.get_realtime_metrics()


@router.post("/export")
async def export_igr_report(
    request: IGRExportRequest,
    user=Depends(require_role(["ministry_admin", "super_admin"])),
):
    """
    Export IGR report to CSV or PDF.
    Report generated async — returns job_id for status polling.
    """
    from app.workers.report_generator import ReportGeneratorWorker
    worker = ReportGeneratorWorker()
    job_id = await worker.enqueue_igr_report(request, user_id=user.id)
    return {"job_id": job_id, "message": "Report generation queued. Check status at /api/v1/reports/{job_id}"}
