"""
ISEYAA — Events Service Database Models
========================================
PostgreSQL models for all event-related entities.
Uses SQLAlchemy 2.x async ORM with Alembic migrations.

PRD Reference: §4.4 Events, Culture & Entertainment
"""

import uuid
from datetime import datetime
from decimal import Decimal
from enum import Enum as PyEnum
from typing import List, Optional

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, ForeignKey, Integer,
    Numeric, String, Text, JSON, Index
)
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


class EventStatus(str, PyEnum):
    DRAFT            = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED         = "approved"
    PUBLISHED        = "published"
    LIVE             = "live"
    COMPLETED        = "completed"
    CANCELLED        = "cancelled"
    REJECTED         = "rejected"


class TicketType(str, PyEnum):
    FREE        = "free"
    PAID        = "paid"
    VIP         = "vip"
    EARLY_BIRD  = "early_bird"
    GROUP       = "group"
    GOVERNMENT  = "government"


class EventCategory(str, PyEnum):
    CULTURAL    = "cultural"
    SPORTS      = "sports"
    MUSIC       = "music"
    CORPORATE   = "corporate"
    GOVERNMENT  = "government"
    ARTS        = "arts"
    FESTIVAL    = "festival"
    CONFERENCE  = "conference"
    EXHIBITION  = "exhibition"


class Event(Base):
    __tablename__ = "events"

    id            = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title         = Column(String(255), nullable=False, index=True)
    slug          = Column(String(300), unique=True, nullable=False, index=True)
    description   = Column(Text)
    category      = Column(Enum(EventCategory), nullable=False)
    status        = Column(Enum(EventStatus), default=EventStatus.DRAFT, index=True)

    # Organiser
    organiser_id  = Column(UUID(as_uuid=True), nullable=False, index=True)
    organiser_name = Column(String(255))

    # Location
    venue_id      = Column(UUID(as_uuid=True), ForeignKey("venues.id"), nullable=True)
    lga           = Column(String(100), index=True)  # Ogun State LGA
    address       = Column(String(500))
    latitude      = Column(Numeric(10, 8))
    longitude     = Column(Numeric(11, 8))
    is_virtual    = Column(Boolean, default=False)
    livestream_url = Column(String(500))

    # Timing
    starts_at     = Column(DateTime(timezone=True), nullable=False, index=True)
    ends_at       = Column(DateTime(timezone=True), nullable=False)
    timezone      = Column(String(50), default="Africa/Lagos")

    # Capacity
    max_capacity  = Column(Integer)
    tickets_sold  = Column(Integer, default=0)
    waitlist_enabled = Column(Boolean, default=False)

    # Financials (₦)
    base_price_ngn = Column(Numeric(15, 2), default=Decimal("0.00"))
    total_revenue_ngn = Column(Numeric(15, 2), default=Decimal("0.00"))
    igr_split_pct  = Column(Numeric(5, 2), default=Decimal("5.00"))  # % to Ogun State IGR
    platform_fee_pct = Column(Numeric(5, 2), default=Decimal("2.50"))

    # Government
    government_approved_by  = Column(UUID(as_uuid=True))
    government_approved_at  = Column(DateTime(timezone=True))
    government_rejection_reason = Column(Text)
    requires_security_clearance = Column(Boolean, default=False)
    expected_attendance     = Column(Integer)

    # AI-generated fields
    ai_generated_schedule   = Column(JSON)  # from AIEventSetupService
    ai_setup_completed      = Column(Boolean, default=False)

    # Media
    banner_url     = Column(String(500))
    gallery_urls   = Column(ARRAY(String), default=[])
    tags           = Column(ARRAY(String), default=[])

    # Meta
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), onupdate=func.now())
    published_at  = Column(DateTime(timezone=True))

    # Relationships
    ticket_tiers  = relationship("TicketTier", back_populates="event", cascade="all, delete-orphan")
    vendor_booths = relationship("VendorBooth",  back_populates="event", cascade="all, delete-orphan")
    sponsorships  = relationship("Sponsorship",  back_populates="event", cascade="all, delete-orphan")

    __table_args__ = (
        Index("idx_events_lga_status",   "lga", "status"),
        Index("idx_events_starts_at",    "starts_at"),
        Index("idx_events_category",     "category"),
    )

    def __repr__(self):
        return f"<Event id={self.id} title={self.title!r} status={self.status}>"

    @property
    def available_capacity(self) -> Optional[int]:
        if self.max_capacity is None:
            return None
        return max(0, self.max_capacity - (self.tickets_sold or 0))

    @property
    def is_sold_out(self) -> bool:
        return self.available_capacity == 0 if self.available_capacity is not None else False


class TicketTier(Base):
    __tablename__ = "ticket_tiers"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id    = Column(UUID(as_uuid=True), ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    name        = Column(String(100), nullable=False)      # e.g. "VIP Gold", "Early Bird"
    ticket_type = Column(Enum(TicketType), nullable=False)
    price_ngn   = Column(Numeric(15, 2), nullable=False, default=Decimal("0.00"))
    quantity    = Column(Integer, nullable=False)
    sold        = Column(Integer, default=0)
    sale_starts = Column(DateTime(timezone=True))
    sale_ends   = Column(DateTime(timezone=True))
    benefits    = Column(JSON)          # list of perks for this tier
    is_active   = Column(Boolean, default=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())

    event       = relationship("Event", back_populates="ticket_tiers")
    tickets     = relationship("Ticket", back_populates="tier")

    @property
    def remaining(self) -> int:
        return max(0, self.quantity - (self.sold or 0))


class Ticket(Base):
    __tablename__ = "tickets"

    id             = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id       = Column(UUID(as_uuid=True), ForeignKey("events.id"), nullable=False, index=True)
    tier_id        = Column(UUID(as_uuid=True), ForeignKey("ticket_tiers.id"), nullable=False)
    holder_id      = Column(UUID(as_uuid=True), nullable=False, index=True)  # citizen user_id
    holder_name    = Column(String(255))
    holder_email   = Column(String(255))
    holder_phone   = Column(String(20))

    # Unique QR code for entry scanning
    qr_code        = Column(String(255), unique=True, nullable=False, index=True)
    qr_code_data   = Column(Text)        # Base64 PNG of QR code

    # Payment
    amount_paid_ngn = Column(Numeric(15, 2), nullable=False)
    payment_reference = Column(String(255), index=True)
    payment_provider  = Column(String(50))  # paystack | flutterwave
    payment_status    = Column(String(50), default="pending")  # pending | confirmed | refunded

    # State
    is_checked_in  = Column(Boolean, default=False)
    checked_in_at  = Column(DateTime(timezone=True))
    checked_in_by  = Column(UUID(as_uuid=True))  # Scanner operator ID
    is_cancelled   = Column(Boolean, default=False)
    is_transferred = Column(Boolean, default=False)
    transferred_to = Column(UUID(as_uuid=True))

    created_at     = Column(DateTime(timezone=True), server_default=func.now())
    updated_at     = Column(DateTime(timezone=True), onupdate=func.now())

    tier  = relationship("TicketTier", back_populates="tickets")

    __table_args__ = (
        Index("idx_tickets_event_holder", "event_id", "holder_id"),
        Index("idx_tickets_payment_ref",  "payment_reference"),
    )


class Venue(Base):
    __tablename__ = "venues"

    id          = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name        = Column(String(255), nullable=False, index=True)
    address     = Column(String(500))
    lga         = Column(String(100), nullable=False, index=True)
    capacity    = Column(Integer)
    latitude    = Column(Numeric(10, 8))
    longitude   = Column(Numeric(11, 8))
    amenities   = Column(ARRAY(String), default=[])
    images      = Column(ARRAY(String), default=[])
    hourly_rate_ngn = Column(Numeric(15, 2))
    is_government_owned = Column(Boolean, default=False)
    is_active   = Column(Boolean, default=True)
    created_at  = Column(DateTime(timezone=True), server_default=func.now())

    events = relationship("Event", back_populates="venue")


class VendorBooth(Base):
    __tablename__ = "vendor_booths"

    id           = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id     = Column(UUID(as_uuid=True), ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    vendor_id    = Column(UUID(as_uuid=True), nullable=False)
    booth_number = Column(String(20))
    floor_section = Column(String(50))
    stall_fee_ngn = Column(Numeric(15, 2), nullable=False)
    payment_status = Column(String(50), default="pending")
    sales_total_ngn = Column(Numeric(15, 2), default=Decimal("0.00"))
    created_at   = Column(DateTime(timezone=True), server_default=func.now())

    event = relationship("Event", back_populates="vendor_booths")


class Sponsorship(Base):
    __tablename__ = "sponsorships"

    id             = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id       = Column(UUID(as_uuid=True), ForeignKey("events.id", ondelete="CASCADE"), nullable=False, index=True)
    sponsor_id     = Column(UUID(as_uuid=True), nullable=False)
    sponsor_name   = Column(String(255))
    package_tier   = Column(String(50))   # platinum | gold | silver | bronze
    amount_ngn     = Column(Numeric(15, 2), nullable=False)
    deliverables   = Column(JSON)         # list of agreed deliverables
    payment_status = Column(String(50), default="pending")
    contract_url   = Column(String(500))
    created_at     = Column(DateTime(timezone=True), server_default=func.now())

    event = relationship("Event", back_populates="sponsorships")
